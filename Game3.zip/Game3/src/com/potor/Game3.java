package com.potor;
import java.util.*;
public class Game3 {

        public static String word = null;
        public static void main(String[] args) {
            Scanner input = new Scanner(System.in);
            System.out.println("This is a guessing words game.");
            System.out.println("Type the word to use or type random to use a random word.");
            word = input.nextLine();
            if(word.equals("random")) {
                switch (rand(11)) {
                    case 0:
                        word = "Encapsulation";
                        break;
                    case 1:
                        word = "Programming";
                        break;
                    case 2:
                        word = "OOP";
                        break;
                    case 3:
                        word = "Smart";
                        break;
                    case 4:
                        word = "Scanner";
                    case 5:
                        word = "Interface";
                        break;
                    case 6:
                        word = "App";
                        break;
                    case 7:
                        word = "Funny";
                        break;
                    case 8:
                        word = "Mac";
                        break;
                    case 9:
                        word = "Computer";
                        break;
                    case 10:
                        word = "Laptop";
                        break;

                }
            }
            wordOne();
        }
        private static int rand(int bound) {
            return (int) (Math.random() * bound);
        }
        public static void wordOne() {
            int tries = 0;
            boolean gotIt = false;
            String inputWord = null;
            Scanner input = new Scanner(System.in);
            System.out.println("You will have 15 tries to get this word");
            if(tries >= 14) {
                System.out.println("You have exided the maximum number of tries.");
                gameOver();
            }
            while (tries <= 15) {
                inputWord = null;
                System.out.println("Enter a letter you think the word may contain");
                System.out.println("If you want to try and guess just type the word.");
                System.out.println("");
                inputWord = input.nextLine();
                tries++;

                if(inputWord.equals(word)) {
                    System.out.println("You have got it nice one!!");
                    sleep(1000);
                    return;
                }
                if(word.contains(inputWord)) {
                    System.out.println("You have guessed right, it does contain a "+inputWord);
                }
                else
                {
                    System.out.println("Sorry you have guessed wrong.");
                }
            }

        }

        public static void gameOver() {
            System.out.println("Thanks for playing my funny game!");
        }
        public static void sleep(int time) {
            try {
                Thread.sleep(time);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }


